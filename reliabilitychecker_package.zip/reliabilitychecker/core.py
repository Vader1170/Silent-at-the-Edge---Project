import numpy as np
from scipy.special import eval_legendre


def to_domain(t, t_ref):
    t = np.asarray(t, dtype=float)
    t_ref = np.asarray(t_ref, dtype=float)
    span = t_ref[-1] - t_ref[0]
    return 2 * (t - t_ref[0]) / span - 1


def trapezoid_weights(x):
    x = np.asarray(x, dtype=float)
    w = np.zeros(len(x))
    w[0] = (x[1] - x[0]) / 2
    w[-1] = (x[-1] - x[-2]) / 2
    w[1:-1] = (x[2:] - x[:-2]) / 2
    return w


def legendre_basis(x, m):
    n = np.arange(m + 1)
    P = np.array([eval_legendre(j, x) for j in range(m + 1)])
    return (P * np.sqrt(n + 0.5)[:, None]).T


def gram_matrices(t, t_ref, m=10):
    x = to_domain(t, t_ref)
    w = trapezoid_weights(x)
    Phi = legendre_basis(x, m)
    G = (Phi * w[:, None]).T @ Phi
    Gd = (Phi * (w ** 2)[:, None]).T @ Phi
    return G, Gd


def edge_vector(m, x0=1.0):
    n = np.arange(m + 1)
    return np.sqrt(n + 0.5) * eval_legendre(n, x0)


def fit_diagnostics(t, t_ref=None, m=10, x0=1.0):
    if t_ref is None:
        t_ref = t
    G, Gd = gram_matrices(t, t_ref, m=m)
    kappa = np.linalg.cond(G)
    Ginv = np.linalg.inv(G)
    phi0 = edge_vector(m, x0=x0)
    var = phi0 @ Ginv @ Gd @ Ginv @ phi0
    leverage = phi0 @ Ginv @ phi0
    return dict(kappa=float(kappa), variance=float(var), leverage=float(leverage))


def reliability_check(t, t_ref=None, m=10, kappa_warn=1e3, kappa_critical=1e6, x0=1.0):
    diag = fit_diagnostics(t, t_ref=t_ref, m=m, x0=x0)
    kappa = diag['kappa']
    if kappa >= kappa_critical:
        status = 'CRITICAL'
    elif kappa >= kappa_warn:
        status = 'WARNING'
    else:
        status = 'OK'
    diag['status'] = status
    return diag


def calibrated_thresholds(t_healthy, t_ref=None, m=10, warn_multiple=10, critical_multiple=1e4, x0=1.0):
    baseline = fit_diagnostics(t_healthy, t_ref=t_ref, m=m, x0=x0)
    kappa0 = baseline['kappa']
    return dict(kappa0=kappa0, kappa_warn=warn_multiple * kappa0, kappa_critical=critical_multiple * kappa0)


def near_chebyshev_nodes(n, alpha=-0.49, eps=1e-3):
    k = np.arange(n)
    theta = np.pi * (k + 0.5) / n
    x = np.cos(theta)
    x = np.clip(x, -1 + eps, 1 - eps)
    return np.sort(x)


def economic_benefit(pct_variance_reduction, n_sensors, cost_per_sensor):
    p = pct_variance_reduction / 100.0
    if p >= 1 or p < 0:
        raise ValueError('pct_variance_reduction must be in [0, 100)')
    equivalent_n = n_sensors / (1 - p)
    sensors_avoided = equivalent_n - n_sensors
    savings = sensors_avoided * cost_per_sensor
    return dict(equivalent_n=equivalent_n, sensors_avoided=sensors_avoided, savings=savings)
