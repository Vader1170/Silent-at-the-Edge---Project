from .core import (
    to_domain,
    trapezoid_weights,
    legendre_basis,
    gram_matrices,
    edge_vector,
    fit_diagnostics,
    reliability_check,
    calibrated_thresholds,
    near_chebyshev_nodes,
    economic_benefit,
)

__all__ = [
    'to_domain',
    'trapezoid_weights',
    'legendre_basis',
    'gram_matrices',
    'edge_vector',
    'fit_diagnostics',
    'reliability_check',
    'calibrated_thresholds',
    'near_chebyshev_nodes',
    'economic_benefit',
]

__version__ = '0.1.0'
