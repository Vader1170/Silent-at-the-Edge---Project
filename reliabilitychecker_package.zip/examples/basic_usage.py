import numpy as np
from reliabilitychecker import reliability_check, calibrated_thresholds, economic_benefit

t = np.linspace(0, 100, 200)
t_dropped = np.concatenate([t[:150], t[195:]])

thresholds = calibrated_thresholds(t, m=10)
result = reliability_check(t_dropped, t_ref=t, m=10,
                            kappa_warn=thresholds['kappa_warn'],
                            kappa_critical=thresholds['kappa_critical'])
print(result)

econ = economic_benefit(pct_variance_reduction=77.6, n_sensors=1, cost_per_sensor=15000)
print(econ)
