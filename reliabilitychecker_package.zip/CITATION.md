Ramakrishnan, S. B., "Silent at the Edge: A Christoffel Classification and Reliability Diagnostic for Polynomial Telemetry Fits," 2026.

BibTeX:

```
@unpublished{ramakrishnan2026silent,
  author = {Ramakrishnan, Sourish Balaji},
  title = {Silent at the Edge: A Christoffel Classification and Reliability Diagnostic for Polynomial Telemetry Fits},
  year = {2026}
}
```
