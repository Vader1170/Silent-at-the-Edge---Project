# reliabilitychecker

A second, independent reliability diagnostic for any real-time polynomial least-squares fit.

## The problem

A polynomial fit to a sliding window of sensor readings reports an estimate and a confidence interval. The confidence interval can look normal while the underlying design is numerically near-singular. On real river telemetry, a sensor dropout inflated the fitting matrix's condition number by up to nine orders of magnitude while the standard variance diagnostic stayed nearly flat. The math and the empirical results are in the accompanying paper, "Silent at the Edge: A Christoffel Classification and Reliability Diagnostic for Polynomial Telemetry Fits."

## The fix

The condition number of the fitting Gram matrix is a byproduct of the same matrix inversion the fit already performs. This package computes it and returns a status: `OK`, `WARNING`, or `CRITICAL`.

## Install

```
pip install -e .
```

## Quick start

```python
import numpy as np
from reliabilitychecker import reliability_check

t = np.linspace(0, 100, 200)
t_dropped = np.concatenate([t[:150], t[195:]])

result = reliability_check(t_dropped, t_ref=t, m=10)
print(result)
```

## Calibrating thresholds to a station's own baseline

```python
from reliabilitychecker import calibrated_thresholds, reliability_check

thresholds = calibrated_thresholds(t_healthy, m=10)
result = reliability_check(t_current, t_ref=t_healthy, m=10,
                            kappa_warn=thresholds['kappa_warn'],
                            kappa_critical=thresholds['kappa_critical'])
```

## Estimating a redesign's economic value

```python
from reliabilitychecker import economic_benefit

economic_benefit(pct_variance_reduction=77.6, n_sensors=1, cost_per_sensor=15000)
```

## What is in the package

| Function | Purpose |
|---|---|
| `to_domain` | Map real timestamps to the [-1, 1] fitting domain |
| `trapezoid_weights` | Trapezoidal quadrature weights for an irregular grid |
| `legendre_basis` | Orthonormal Legendre design matrix |
| `gram_matrices` | The fit's Gram matrix and its data-weighted analogue |
| `fit_diagnostics` | Condition number, edge variance, and leverage from a design |
| `reliability_check` | `OK` / `WARNING` / `CRITICAL` from a design's condition number |
| `calibrated_thresholds` | Warning and critical thresholds relative to a station's own healthy baseline |
| `near_chebyshev_nodes` | Sample placement close to the variance-optimal Chebyshev distribution |
| `economic_benefit` | Converts a variance reduction into an equivalent-hardware cost figure |

## Tests

```
python tests/test_core.py
```

## Citation

If this is useful in other work, please cite the accompanying paper (see `CITATION.md`).

## License

MIT. See `LICENSE`.
