import numpy as np
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from reliabilitychecker import (
    reliability_check,
    fit_diagnostics,
    calibrated_thresholds,
    near_chebyshev_nodes,
    economic_benefit,
)


def test_uniform_grid_is_ok():
    t = np.linspace(0, 100, 200)
    result = reliability_check(t, m=10)
    assert result['status'] == 'OK'
    assert result['kappa'] < 10


def test_dropout_raises_condition_number():
    t_full = np.linspace(0, 100, 200)
    t_dropped = np.concatenate([t_full[:150], t_full[195:]])
    healthy = fit_diagnostics(t_full, t_ref=t_full, m=10)
    dropped = fit_diagnostics(t_dropped, t_ref=t_full, m=10)
    assert dropped['kappa'] > healthy['kappa']


def test_calibrated_thresholds_scale_with_baseline():
    t = np.linspace(0, 100, 200)
    thresholds = calibrated_thresholds(t, m=10, warn_multiple=10, critical_multiple=1e4)
    assert thresholds['kappa_warn'] == 10 * thresholds['kappa0']
    assert thresholds['kappa_critical'] == 1e4 * thresholds['kappa0']


def test_near_chebyshev_nodes_are_sorted_and_bounded():
    x = near_chebyshev_nodes(50)
    assert np.all(np.diff(x) > 0)
    assert x.min() > -1 and x.max() < 1


def test_economic_benefit_matches_formula():
    result = economic_benefit(pct_variance_reduction=50, n_sensors=10, cost_per_sensor=100)
    assert abs(result['equivalent_n'] - 20) < 1e-9
    assert abs(result['sensors_avoided'] - 10) < 1e-9
    assert abs(result['savings'] - 1000) < 1e-9


def test_economic_benefit_rejects_invalid_input():
    try:
        economic_benefit(pct_variance_reduction=100, n_sensors=10, cost_per_sensor=100)
        assert False
    except ValueError:
        pass


if __name__ == '__main__':
    test_uniform_grid_is_ok()
    test_dropout_raises_condition_number()
    test_calibrated_thresholds_scale_with_baseline()
    test_near_chebyshev_nodes_are_sorted_and_bounded()
    test_economic_benefit_matches_formula()
    test_economic_benefit_rejects_invalid_input()
    print('all tests passed')
